#include "Father.h"
#include "Son.h"
#include "stdio.h"
int main()
{

	Son S;
	return 0;
}