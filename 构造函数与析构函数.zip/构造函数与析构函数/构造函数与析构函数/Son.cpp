#include "Son.h"
#include "stdio.h"


Son::Son()
{
	printf("Son has been create!");
}


Son::~Son()
{
	printf("Son has been destroyed!");
}
