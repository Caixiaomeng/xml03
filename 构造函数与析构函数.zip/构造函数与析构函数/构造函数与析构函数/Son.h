#pragma once
#include "Father.h"
class Son :
	public Father
{
public:
	Son();
	~Son();
};

