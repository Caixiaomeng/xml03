#include "Father.h"
#include "stdio.h"


Father::Father()
{
	printf("Father has been create!");
}


Father::~Father()
{
	printf("Father has been destroyed!");
}
