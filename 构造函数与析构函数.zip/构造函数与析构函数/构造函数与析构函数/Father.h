#pragma once
class Father
{
public:
	Father();
	~Father();
};

